"""
URL configuration for learn_hub project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views

from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from users.views import RoleBasedLoginView
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('core.urls')),
    path('users/', include('users.urls')),
    path('admin-panel/', include('admin_panel.urls')),
    path('instructor/', include('instructor.urls')),
    path('student/', include('student.urls')),
    path('career/', include('career_hub.urls')),
    path('discussions/', include('discussions.urls')),
    path('notifications/', include('notifications.urls')),
    path('gamification/', include('gamification.urls')),
    path('messaging/', include('messaging.urls')),
    path('support/', include('support.urls')),
    path('learning/', include('learning.urls')),
    path('analytics/', include('analytics.urls')),
    path('assessments/', include('assessments.urls')),
    path('certificates/', include('certificates.urls')),
    path('live-classes/', include('live_classes.urls')),

    # Auth — role-based redirect on login
    path('login/', RoleBasedLoginView.as_view(), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
